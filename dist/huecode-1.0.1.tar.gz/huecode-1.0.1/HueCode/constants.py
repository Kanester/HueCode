from enum import Enum

class constants(Enum):
  SF = 50
  BC = (0,0,0)
  
  CF = 30
  rgbC = ["R", "G", "B"]
  CS = {
    "R": 50,
    "G": 80,
    "B": 140
  }